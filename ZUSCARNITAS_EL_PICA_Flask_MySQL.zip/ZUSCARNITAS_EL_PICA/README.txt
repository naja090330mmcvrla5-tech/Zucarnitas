ZUSCARNITAS EL PICA - versión inicial Flask + MySQL

CONTENIDO
- app.py: aplicación Flask con login y módulos básicos.
- requirements.txt: dependencias de Python.
- crear_bd.sql: crea la base de datos MySQL.
- README.txt: instrucciones.

REQUISITOS
- Python 3.10 o superior.
- MySQL Server encendido (o XAMPP con MySQL activo).
- Una base de datos llamada zus_carnitas.
- En Windows, mysqlclient puede necesitar herramientas de compilación. Si falla la instalación, dime el error exacto y tu versión de Python.

INSTALACIÓN EN WINDOWS (CMD)
1. Extrae el ZIP a una carpeta.
2. Abre CMD dentro de esa carpeta.
3. Crea un entorno virtual:
   py -m venv venv
   venv\Scripts\activate
4. Instala dependencias:
   pip install -r requirements.txt
5. Entra a MySQL Workbench o phpMyAdmin y ejecuta crear_bd.sql.
6. Si tu MySQL tiene contraseña, configura las variables de entorno antes de arrancar:
   set MYSQL_USER=root
   set MYSQL_PASSWORD=TU_CONTRASEÑA
   set MYSQL_DB=zus_carnitas
   set APP_USER=admin
   set APP_PASSWORD=CAMBIA_ESTA_CLAVE
   set FLASK_SECRET_KEY=una_clave_larga_y_aleatoria
7. Ejecuta:
   python app.py
8. Abre en el navegador:
   http://127.0.0.1:5000
9. Acceso inicial si no configuraste variables: admin / 1234.

MÓDULOS INCLUIDOS
- Inicio/resumen
- Punto de venta y ventas fiadas
- Compras que aumentan inventario
- Inventario y ajustes manuales
- Preparación que descuenta carne en Kg
- Abonos a fiados
- Entradas y salidas de caja
- Consumo interno que descuenta inventario
- Cierre del día
- Reportes por rango de fechas
- Exportación de ventas a CSV

IMPORTANTE
- Es una primera versión funcional para probar el flujo. No incluye impresión de tickets ni descuento automático de tortillas por tacos/tortas, porque falta confirmar tus reglas exactas de productos y recetas.
- El descuento de una venta sobre inventario ocurre solamente cuando el nombre del concepto de venta coincide exactamente con el nombre de un artículo en inventario. Por eso, para vender tacos/tortas con descuento de ingredientes se debe definir una tabla de productos/recetas.
- Antes de usar con dinero real, cambia las claves, agrega usuarios con contraseñas seguras y configura respaldos.
- La aplicación crea las tablas si no existen; no borra tablas.
