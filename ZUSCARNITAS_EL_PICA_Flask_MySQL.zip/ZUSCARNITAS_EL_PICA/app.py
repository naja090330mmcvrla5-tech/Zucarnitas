from flask import Flask, request, redirect, url_for, flash, session, render_template_string, Response
from flask_mysqldb import MySQL
from functools import wraps
from datetime import datetime
from decimal import Decimal, InvalidOperation
import csv
import io
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", "cambia_esta_clave_secreta")
app.config["MYSQL_HOST"] = os.environ.get("MYSQL_HOST", "localhost")
app.config["MYSQL_USER"] = os.environ.get("MYSQL_USER", "root")
app.config["MYSQL_PASSWORD"] = os.environ.get("MYSQL_PASSWORD", "")
app.config["MYSQL_DB"] = os.environ.get("MYSQL_DB", "zus_carnitas")
app.config["MYSQL_CURSORCLASS"] = "DictCursor"
mysql = MySQL(app)

# Credenciales iniciales de demostración. Cámbialas antes de usar el sistema en producción.
ADMIN_USER = os.environ.get("APP_USER", "admin")
ADMIN_PASSWORD = os.environ.get("APP_PASSWORD", "1234")

SCHEMA = [
"""CREATE TABLE IF NOT EXISTS inventario (
  concepto VARCHAR(150) PRIMARY KEY,
  cantidad DECIMAL(12,3) NOT NULL DEFAULT 0,
  unidad VARCHAR(30) NOT NULL DEFAULT 'Piezas',
  costo_promedio DECIMAL(12,2) NOT NULL DEFAULT 0,
  actualizado TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB""",
"""CREATE TABLE IF NOT EXISTS compras (
  id VARCHAR(40) PRIMARY KEY,
  fecha DATE NOT NULL,
  concepto VARCHAR(150) NOT NULL,
  tipo VARCHAR(80) NOT NULL,
  cantidad DECIMAL(12,3) NOT NULL,
  unidad VARCHAR(30) NOT NULL,
  costo_total DECIMAL(12,2) NOT NULL DEFAULT 0,
  proveedor VARCHAR(150) DEFAULT '',
  notas TEXT
) ENGINE=InnoDB""",
"""CREATE TABLE IF NOT EXISTS preparaciones (
  id VARCHAR(40) PRIMARY KEY,
  fecha DATE NOT NULL,
  carne_utilizada_kg DECIMAL(12,3) NOT NULL,
  tipo_carne VARCHAR(150) NOT NULL
) ENGINE=InnoDB""",
"""CREATE TABLE IF NOT EXISTS ventas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaccion_id VARCHAR(40) NOT NULL,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  concepto VARCHAR(150) NOT NULL,
  cantidad DECIMAL(12,3) NOT NULL,
  p_unitario DECIMAL(12,2) NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  estado VARCHAR(30) NOT NULL DEFAULT 'COMPLETADA',
  metodo_pago VARCHAR(30) NOT NULL DEFAULT 'Efectivo',
  cliente VARCHAR(150) NOT NULL DEFAULT 'Público General',
  monto_pagado DECIMAL(12,2) NOT NULL DEFAULT 0,
  saldo_pendiente DECIMAL(12,2) NOT NULL DEFAULT 0,
  INDEX idx_ventas_fecha (fecha),
  INDEX idx_ventas_transaccion (transaccion_id),
  INDEX idx_ventas_fiado (metodo_pago, saldo_pendiente)
) ENGINE=InnoDB""",
"""CREATE TABLE IF NOT EXISTS cierres_dia (
  fecha DATE PRIMARY KEY,
  carne_sobrante_kg DECIMAL(12,3) NOT NULL DEFAULT 0,
  tortillas_sobrantes INT NOT NULL DEFAULT 0,
  notas TEXT
) ENGINE=InnoDB""",
"""CREATE TABLE IF NOT EXISTS movimientos_caja (
  id VARCHAR(40) PRIMARY KEY,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  tipo VARCHAR(20) NOT NULL,
  concepto VARCHAR(150) NOT NULL,
  monto DECIMAL(12,2) NOT NULL,
  usuario_notas TEXT,
  INDEX idx_movimientos_fecha (fecha)
) ENGINE=InnoDB""",
"""CREATE TABLE IF NOT EXISTS consumo_interno (
  id VARCHAR(40) PRIMARY KEY,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  concepto VARCHAR(150) NOT NULL,
  cantidad DECIMAL(12,3) NOT NULL
) ENGINE=InnoDB"""
]

STYLE = """
<style>
:root{--azul:#053787;--naranja:#ff6600;--fondo:#f4f6fb}
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:var(--fondo);color:#202938}
header{background:var(--azul);color:white;padding:18px 24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap}
header h1{margin:0;font-size:23px}header a{color:white;margin-left:12px}
nav{background:#fff;padding:12px 20px;display:flex;gap:8px;flex-wrap:wrap;box-shadow:0 2px 5px #ddd}
nav a,.btn{background:var(--naranja);color:white;padding:9px 12px;border:0;border-radius:5px;text-decoration:none;cursor:pointer;font-weight:bold}
main{max-width:1150px;margin:22px auto;padding:0 14px}.card{background:white;padding:18px;margin:14px 0;border-radius:9px;box-shadow:0 2px 7px #ddd}
h2{color:var(--azul);margin-top:0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
label{display:block;font-weight:bold;margin:8px 0 4px}input,select,textarea{width:100%;padding:10px;border:1px solid #c9ced8;border-radius:5px;font-size:15px}
button{font-size:14px}.flash{padding:10px;margin:8px 0;border-radius:5px;background:#fff1d9;border-left:4px solid var(--naranja)}
table{width:100%;border-collapse:collapse;background:white}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left}th{background:#e9eef8;color:var(--azul)}
.small{font-size:13px;color:#5b6472}.danger{background:#b42318}.stats{font-size:24px;font-weight:bold;color:var(--azul)}
@media(max-width:600px){header{display:block}nav a{font-size:12px}}
</style>
"""

BASE = """
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{ title }} - ZUSCARNITAS EL PICA</title>""" + STYLE + """</head><body>
<header><h1>ZUSCARNITAS EL PICA</h1><div>{% if session.get('logged_in') %}Sesión: {{ session.get('usuario') }} · <a href="{{ url_for('logout') }}">Salir</a>{% endif %}</div></header>
{% if session.get('logged_in') %}<nav>
<a href="{{ url_for('index') }}">Inicio</a><a href="{{ url_for('ventas') }}">Punto de venta</a><a href="{{ url_for('compras') }}">Compras</a><a href="{{ url_for('inventario') }}">Inventario</a><a href="{{ url_for('preparaciones') }}">Preparación</a><a href="{{ url_for('fiados') }}">Fiados</a><a href="{{ url_for('caja') }}">Caja</a><a href="{{ url_for('consumo') }}">Consumo interno</a><a href="{{ url_for('cierres') }}">Cierre del día</a><a href="{{ url_for('reportes') }}">Reportes</a><a href="{{ url_for('exportar') }}">Exportar ventas CSV</a>
</nav>{% endif %}
<main>{% for message in get_flashed_messages() %}<div class="flash">{{ message }}</div>{% endfor %}{{ body|safe }}</main></body></html>
"""

def page(title, body, **context):
    return render_template_string(BASE, title=title, body=render_template_string(body, **context))

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def db_cursor():
    return mysql.connection.cursor()

def setup_database():
    # La base de datos indicada en MYSQL_DB debe existir antes de arrancar la app.
    with app.app_context():
        cur = db_cursor()
        for sql in SCHEMA:
            cur.execute(sql)
        mysql.connection.commit()
        cur.close()

def as_decimal(value, field_name="cantidad"):
    try:
        number = Decimal(str(value or "0"))
        if not number.is_finite():
            raise InvalidOperation
        return number
    except (InvalidOperation, ValueError):
        raise ValueError(f"El valor de {field_name} no es válido.")

def money(value):
    return f"${Decimal(str(value or 0)):,.2f}"

def inventory_change(cur, concepto, delta, unidad, costo_total=0):
    cur.execute("SELECT cantidad, costo_promedio FROM inventario WHERE concepto=%s FOR UPDATE", (concepto,))
    row = cur.fetchone()
    delta = Decimal(str(delta))
    if row:
        old_qty = Decimal(str(row["cantidad"]))
        old_cost = Decimal(str(row["costo_promedio"] or 0))
        new_qty = old_qty + delta
        if new_qty < 0:
            raise ValueError(f"No hay suficiente inventario de {concepto}. Existencia: {old_qty} {unidad}.")
        cost = Decimal(str(costo_total or 0))
        if delta > 0 and cost > 0 and new_qty > 0:
            avg = ((old_qty * old_cost) + cost) / new_qty
        else:
            avg = old_cost
        cur.execute("UPDATE inventario SET cantidad=%s, unidad=%s, costo_promedio=%s WHERE concepto=%s",
                    (str(new_qty), unidad, str(avg), concepto))
    else:
        if delta < 0:
            raise ValueError(f"No existe inventario suficiente para {concepto}.")
        qty = delta
        avg = (Decimal(str(costo_total or 0)) / qty) if qty > 0 else Decimal("0")
        cur.execute("INSERT INTO inventario(concepto,cantidad,unidad,costo_promedio) VALUES(%s,%s,%s,%s)",
                    (concepto, str(qty), unidad, str(avg)))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = request.form.get("usuario", "")
        password = request.form.get("password", "")
        if user == ADMIN_USER and password == ADMIN_PASSWORD:
            session["logged_in"] = True
            session["usuario"] = user
            return redirect(url_for("index"))
        flash("Usuario o contraseña incorrectos.")
    body = """
    <div class="card" style="max-width:420px;margin:60px auto"><h2>Iniciar sesión</h2>
    <form method="post"><label>Usuario</label><input name="usuario" required>
    <label>Contraseña</label><input name="password" type="password" required>
    <p><button class="btn">Entrar</button></p><p class="small">Acceso inicial: admin / 1234. Cámbialo mediante variables de entorno antes de usarlo.</p></form></div>"""
    return page("Login", body)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def index():
    cur = db_cursor()
    cur.execute("SELECT COALESCE(SUM(total),0) total, COALESCE(SUM(monto_pagado),0) cobrado FROM ventas WHERE fecha=CURDATE()")
    ventas_hoy = cur.fetchone()
    cur.execute("SELECT COUNT(*) n FROM ventas WHERE fecha=CURDATE()")
    cuenta = cur.fetchone()["n"]
    cur.execute("SELECT concepto,cantidad,unidad FROM inventario ORDER BY concepto LIMIT 8")
    items = cur.fetchall()
    cur.close()
    body = """
    <div class="card"><h2>Panel principal</h2><p>Control básico de ventas, compras, inventario y caja.</p>
    <div class="grid"><div><div class="small">Ventas registradas hoy</div><div class="stats">{{ cuenta }}</div></div>
    <div><div class="small">Importe vendido hoy</div><div class="stats">{{ total }}</div></div>
    <div><div class="small">Cobrado hoy</div><div class="stats">{{ cobrado }}</div></div></div></div>
    <div class="card"><h2>Inventario reciente</h2>{% if items %}<table><tr><th>Concepto</th><th>Existencia</th><th>Unidad</th></tr>{% for x in items %}<tr><td>{{ x.concepto }}</td><td>{{ x.cantidad }}</td><td>{{ x.unidad }}</td></tr>{% endfor %}</table>{% else %}<p>No hay artículos todavía. Registra una compra para dar de alta inventario.</p>{% endif %}</div>
    """
    return page("Inicio", body, cuenta=cuenta, total=money(ventas_hoy["total"]), cobrado=money(ventas_hoy["cobrado"]), items=items)

@app.route("/ventas", methods=["GET", "POST"])
@login_required
def ventas():
    if request.method == "POST":
        try:
            concepto = request.form["concepto"].strip()
            cantidad = as_decimal(request.form["cantidad"])
            precio = as_decimal(request.form["precio"], "precio")
            metodo = request.form.get("metodo_pago", "Efectivo")
            cliente = request.form.get("cliente", "").strip() or "Público General"
            pagado = as_decimal(request.form.get("monto_pagado", "0"), "monto pagado")
            total = cantidad * precio
            if not concepto or cantidad <= 0 or precio < 0:
                raise ValueError("Concepto, cantidad y precio deben ser válidos.")
            if metodo == "Fiado" and cliente == "Público General":
                raise ValueError("Para registrar una venta fiada escribe el nombre del cliente.")
            if pagado < 0 or pagado > total:
                raise ValueError("El monto pagado debe estar entre cero y el total.")
            if metodo != "Fiado":
                pagado = total
            saldo = total - pagado
            estado = "PENDIENTE" if saldo > 0 else "COMPLETADA"
            trans_id = datetime.now().strftime("%Y%m%d%H%M%S%f")
            cur = db_cursor()
            cur.execute("""INSERT INTO ventas(transaccion_id,fecha,hora,concepto,cantidad,p_unitario,total,estado,metodo_pago,cliente,monto_pagado,saldo_pendiente)
                           VALUES(%s,CURDATE(),CURTIME(),%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                        (trans_id, concepto, str(cantidad), str(precio), str(total), estado, metodo, cliente, str(pagado), str(saldo)))
            # Descuenta automáticamente si el concepto coincide con un artículo registrado en inventario.
            cur.execute("SELECT cantidad, unidad FROM inventario WHERE concepto=%s FOR UPDATE", (concepto,))
            stock = cur.fetchone()
            if stock:
                inventory_change(cur, concepto, -cantidad, stock["unidad"])
            mysql.connection.commit()
            cur.close()
            flash(f"Venta registrada. Total: {money(total)}.")
            return redirect(url_for("ventas"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur = db_cursor()
    cur.execute("SELECT id,fecha,hora,concepto,cantidad,total,metodo_pago,cliente,monto_pagado,saldo_pendiente FROM ventas ORDER BY id DESC LIMIT 30")
    rows = cur.fetchall()
    cur.execute("SELECT concepto,unidad FROM inventario ORDER BY concepto")
    stock_items = cur.fetchall()
    cur.close()
    body = """
    <div class="card"><h2>Punto de venta</h2><form method="post"><div class="grid">
    <div><label>Producto / concepto</label><input name="concepto" list="productos" required><datalist id="productos">{% for x in stock_items %}<option value="{{ x.concepto }}">{% endfor %}</datalist></div>
    <div><label>Cantidad</label><input name="cantidad" type="number" min="0.001" step="0.001" required></div>
    <div><label>Precio unitario ($)</label><input name="precio" type="number" min="0" step="0.01" required></div>
    <div><label>Método de pago</label><select name="metodo_pago"><option>Efectivo</option><option>Transferencia</option><option>Fiado</option></select></div>
    <div><label>Cliente (obligatorio si es fiado)</label><input name="cliente" placeholder="Público General"></div>
    <div><label>Monto pagado ($, para fiado)</label><input name="monto_pagado" type="number" min="0" step="0.01" value="0"></div>
    </div><p><button class="btn">Registrar venta</button></p></form></div>
    <div class="card"><h2>Últimas ventas</h2><table><tr><th>Fecha</th><th>Concepto</th><th>Cant.</th><th>Total</th><th>Pago</th><th>Cliente</th><th>Saldo</th></tr>
    {% for x in rows %}<tr><td>{{ x.fecha }} {{ x.hora }}</td><td>{{ x.concepto }}</td><td>{{ x.cantidad }}</td><td>{{ x.total }}</td><td>{{ x.metodo_pago }}</td><td>{{ x.cliente }}</td><td>{{ x.saldo_pendiente }}</td></tr>{% endfor %}</table></div>
    """
    return page("Punto de venta", body, rows=rows, stock_items=stock_items)

@app.route("/compras", methods=["GET", "POST"])
@login_required
def compras():
    if request.method == "POST":
        try:
            concepto = request.form["concepto"].strip()
            tipo = request.form.get("tipo", "Insumos / Consumibles")
            cantidad = as_decimal(request.form["cantidad"])
            unidad = request.form.get("unidad", "Piezas")
            costo = as_decimal(request.form["costo_total"], "costo total")
            proveedor = request.form.get("proveedor", "").strip()
            fecha = request.form.get("fecha") or datetime.now().strftime("%Y-%m-%d")
            if not concepto or cantidad <= 0 or costo < 0:
                raise ValueError("Concepto, cantidad y costo deben ser válidos.")
            ident = datetime.now().strftime("C%Y%m%d%H%M%S%f")
            cur = db_cursor()
            cur.execute("INSERT INTO compras(id,fecha,concepto,tipo,cantidad,unidad,costo_total,proveedor) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)",
                        (ident, fecha, concepto, tipo, str(cantidad), unidad, str(costo), proveedor))
            inventory_change(cur, concepto, cantidad, unidad, costo)
            mysql.connection.commit()
            cur.close()
            flash("Compra guardada y agregada al inventario.")
            return redirect(url_for("compras"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur = db_cursor()
    cur.execute("SELECT * FROM compras ORDER BY fecha DESC LIMIT 50")
    rows = cur.fetchall()
    cur.close()
    body = """
    <div class="card"><h2>Registrar compra</h2><form method="post"><div class="grid">
    <div><label>Fecha</label><input name="fecha" type="date" value="{{ hoy }}" required></div>
    <div><label>Concepto / insumo</label><input name="concepto" required></div>
    <div><label>Tipo</label><select name="tipo"><option>Puerco Entero / Canal (Kg)</option><option>Carne Directa ($ / Kg)</option><option selected>Insumos / Consumibles</option><option>Gas</option><option>Bebidas</option><option>Otro</option></select></div>
    <div><label>Cantidad</label><input name="cantidad" type="number" step="0.001" min="0.001" required></div>
    <div><label>Unidad</label><select name="unidad"><option>Kg</option><option>Piezas</option><option>Paquetes</option><option>Botellas</option><option>Cargas</option><option>Litros</option><option>Unidades</option></select></div>
    <div><label>Costo total ($)</label><input name="costo_total" type="number" min="0" step="0.01" required></div>
    <div><label>Proveedor</label><input name="proveedor"></div></div><p><button class="btn">Guardar compra</button></p></form></div>
    <div class="card"><h2>Últimas compras</h2><table><tr><th>Fecha</th><th>Concepto</th><th>Tipo</th><th>Cantidad</th><th>Unidad</th><th>Costo</th><th>Proveedor</th></tr>
    {% for x in rows %}<tr><td>{{ x.fecha }}</td><td>{{ x.concepto }}</td><td>{{ x.tipo }}</td><td>{{ x.cantidad }}</td><td>{{ x.unidad }}</td><td>{{ x.costo_total }}</td><td>{{ x.proveedor }}</td></tr>{% endfor %}</table></div>
    """
    return page("Compras", body, rows=rows, hoy=datetime.now().strftime("%Y-%m-%d"))

@app.route("/inventario", methods=["GET", "POST"])
@login_required
def inventario():
    if request.method == "POST":
        try:
            concepto = request.form["concepto"].strip()
            cantidad = as_decimal(request.form["cantidad"])
            unidad = request.form.get("unidad", "Piezas")
            if not concepto or cantidad < 0: raise ValueError("Revisa concepto y cantidad.")
            cur = db_cursor()
            cur.execute("SELECT concepto FROM inventario WHERE concepto=%s", (concepto,))
            if cur.fetchone():
                cur.execute("UPDATE inventario SET cantidad=%s, unidad=%s WHERE concepto=%s", (str(cantidad), unidad, concepto))
            else:
                cur.execute("INSERT INTO inventario(concepto,cantidad,unidad) VALUES(%s,%s,%s)", (concepto,str(cantidad),unidad))
            mysql.connection.commit(); cur.close()
            flash("Inventario actualizado.")
            return redirect(url_for("inventario"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur = db_cursor(); cur.execute("SELECT * FROM inventario ORDER BY concepto"); rows = cur.fetchall(); cur.close()
    body = """
    <div class="card"><h2>Ajuste manual de inventario</h2><p class="small">Usa esta opción para dar de alta o corregir existencias. Para movimientos normales, registra compras o ventas.</p>
    <form method="post"><div class="grid"><div><label>Concepto</label><input name="concepto" required></div><div><label>Existencia final</label><input name="cantidad" type="number" min="0" step="0.001" required></div><div><label>Unidad</label><input name="unidad" value="Piezas" required></div></div><p><button class="btn">Guardar existencia</button></p></form></div>
    <div class="card"><h2>Inventario actual</h2><table><tr><th>Concepto</th><th>Cantidad</th><th>Unidad</th><th>Costo promedio</th></tr>{% for x in rows %}<tr><td>{{ x.concepto }}</td><td>{{ x.cantidad }}</td><td>{{ x.unidad }}</td><td>{{ x.costo_promedio }}</td></tr>{% endfor %}</table></div>"""
    return page("Inventario", body, rows=rows)

@app.route("/preparaciones", methods=["GET", "POST"])
@login_required
def preparaciones():
    if request.method == "POST":
        try:
            tipo = request.form["tipo_carne"].strip()
            kg = as_decimal(request.form["kg"])
            fecha = request.form.get("fecha") or datetime.now().strftime("%Y-%m-%d")
            if kg <= 0: raise ValueError("Los kilos deben ser mayores a cero.")
            ident = datetime.now().strftime("P%Y%m%d%H%M%S%f")
            cur = db_cursor()
            inventory_change(cur, tipo, -kg, "Kg")
            cur.execute("INSERT INTO preparaciones(id,fecha,carne_utilizada_kg,tipo_carne) VALUES(%s,%s,%s,%s)", (ident,fecha,str(kg),tipo))
            mysql.connection.commit(); cur.close()
            flash("Preparación registrada y carne descontada del inventario.")
            return redirect(url_for("preparaciones"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur = db_cursor(); cur.execute("SELECT concepto,cantidad,unidad FROM inventario WHERE unidad='Kg' ORDER BY concepto"); items = cur.fetchall()
    cur.execute("SELECT * FROM preparaciones ORDER BY fecha DESC LIMIT 30"); rows = cur.fetchall(); cur.close()
    body = """
    <div class="card"><h2>Registrar preparación</h2><form method="post"><div class="grid"><div><label>Carne / inventario en Kg</label><select name="tipo_carne" required>{% for x in items %}<option value="{{ x.concepto }}">{{ x.concepto }} ({{ x.cantidad }} Kg)</option>{% endfor %}</select></div><div><label>Kilos utilizados</label><input name="kg" type="number" step="0.001" min="0.001" required></div><div><label>Fecha</label><input name="fecha" type="date" value="{{ hoy }}" required></div></div><p><button class="btn">Registrar preparación</button></p></form></div>
    <div class="card"><h2>Historial</h2><table><tr><th>Fecha</th><th>Tipo de carne</th><th>Kg utilizados</th></tr>{% for x in rows %}<tr><td>{{ x.fecha }}</td><td>{{ x.tipo_carne }}</td><td>{{ x.carne_utilizada_kg }}</td></tr>{% endfor %}</table></div>"""
    return page("Preparación", body, items=items, rows=rows, hoy=datetime.now().strftime("%Y-%m-%d"))

@app.route("/fiados", methods=["GET", "POST"])
@login_required
def fiados():
    if request.method == "POST":
        try:
            cliente = request.form["cliente"].strip()
            monto = as_decimal(request.form["monto"])
            if not cliente or monto <= 0: raise ValueError("Escribe el cliente y un monto válido.")
            cur = db_cursor()
            cur.execute("SELECT id,saldo_pendiente FROM ventas WHERE cliente=%s AND metodo_pago='Fiado' AND saldo_pendiente>0 ORDER BY fecha,hora,id", (cliente,))
            debts = cur.fetchall()
            if not debts: raise ValueError("Ese cliente no tiene saldo pendiente.")
            restante = monto
            for debt in debts:
                if restante <= 0: break
                saldo = Decimal(str(debt["saldo_pendiente"]))
                aplicado = min(restante, saldo)
                nuevo = saldo - aplicado
                cur.execute("UPDATE ventas SET monto_pagado=monto_pagado+%s,saldo_pendiente=%s,estado=%s WHERE id=%s",
                            (str(aplicado),str(nuevo),"COMPLETADA" if nuevo == 0 else "PENDIENTE",debt["id"]))
                restante -= aplicado
            aplicado_total = monto - restante
            if aplicado_total > 0:
                ident = datetime.now().strftime("M%Y%m%d%H%M%S%f")
                cur.execute("INSERT INTO movimientos_caja(id,fecha,hora,tipo,concepto,monto,usuario_notas) VALUES(%s,CURDATE(),CURTIME(),'ENTRADA',%s,%s,%s)",
                            (ident,"Abono de fiado: "+cliente,str(aplicado_total),"Abono a cuenta por cobrar"))
            mysql.connection.commit(); cur.close()
            flash(f"Abono registrado: {money(aplicado_total)}.")
            return redirect(url_for("fiados"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur = db_cursor()
    cur.execute("SELECT cliente,SUM(saldo_pendiente) saldo,COUNT(*) operaciones FROM ventas WHERE metodo_pago='Fiado' AND saldo_pendiente>0 GROUP BY cliente ORDER BY cliente")
    clientes = cur.fetchall()
    cur.execute("SELECT fecha,cliente,concepto,total,monto_pagado,saldo_pendiente FROM ventas WHERE metodo_pago='Fiado' AND saldo_pendiente>0 ORDER BY fecha DESC")
    rows = cur.fetchall(); cur.close()
    body = """
    <div class="card"><h2>Abonar a cuenta</h2><form method="post"><div class="grid"><div><label>Cliente (escribe exactamente el nombre)</label><input name="cliente" required></div><div><label>Monto del abono ($)</label><input name="monto" type="number" min="0.01" step="0.01" required></div></div><p><button class="btn">Registrar abono</button></p></form></div>
    <div class="card"><h2>Saldos por cliente</h2><table><tr><th>Cliente</th><th>Operaciones</th><th>Saldo</th></tr>{% for x in clientes %}<tr><td>{{ x.cliente }}</td><td>{{ x.operaciones }}</td><td>{{ x.saldo }}</td></tr>{% else %}<tr><td colspan="3">No hay fiados pendientes.</td></tr>{% endfor %}</table></div>
    <div class="card"><h2>Detalle de fiados pendientes</h2><table><tr><th>Fecha</th><th>Cliente</th><th>Concepto</th><th>Total</th><th>Pagado</th><th>Saldo</th></tr>{% for x in rows %}<tr><td>{{ x.fecha }}</td><td>{{ x.cliente }}</td><td>{{ x.concepto }}</td><td>{{ x.total }}</td><td>{{ x.monto_pagado }}</td><td>{{ x.saldo_pendiente }}</td></tr>{% endfor %}</table></div>"""
    return page("Fiados", body, clientes=clientes, rows=rows)

@app.route("/caja", methods=["GET", "POST"])
@login_required
def caja():
    if request.method == "POST":
        try:
            tipo = request.form["tipo"]
            concepto = request.form["concepto"].strip()
            monto = as_decimal(request.form["monto"])
            notas = request.form.get("notas", "")
            if tipo not in ("ENTRADA","SALIDA") or not concepto or monto <= 0: raise ValueError("Revisa tipo, concepto y monto.")
            ident = datetime.now().strftime("M%Y%m%d%H%M%S%f")
            cur = db_cursor()
            cur.execute("INSERT INTO movimientos_caja(id,fecha,hora,tipo,concepto,monto,usuario_notas) VALUES(%s,CURDATE(),CURTIME(),%s,%s,%s,%s)", (ident,tipo,concepto,str(monto),notas))
            mysql.connection.commit(); cur.close()
            flash("Movimiento de caja registrado.")
            return redirect(url_for("caja"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur = db_cursor(); cur.execute("SELECT * FROM movimientos_caja ORDER BY fecha DESC,hora DESC LIMIT 50"); rows=cur.fetchall()
    cur.execute("SELECT COALESCE(SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE 0 END),0) entradas, COALESCE(SUM(CASE WHEN tipo='SALIDA' THEN monto ELSE 0 END),0) salidas FROM movimientos_caja WHERE fecha=CURDATE()")
    totals=cur.fetchone(); cur.close()
    body = """
    <div class="card"><h2>Entrada / salida de caja</h2><form method="post"><div class="grid"><div><label>Tipo</label><select name="tipo"><option>ENTRADA</option><option>SALIDA</option></select></div><div><label>Concepto</label><input name="concepto" required></div><div><label>Monto ($)</label><input name="monto" type="number" min="0.01" step="0.01" required></div><div><label>Notas</label><input name="notas"></div></div><p><button class="btn">Guardar movimiento</button></p></form></div>
    <div class="card"><h2>Resumen de hoy</h2><div class="grid"><div>Entradas: <b>{{ entradas }}</b></div><div>Salidas: <b>{{ salidas }}</b></div></div></div>
    <div class="card"><h2>Movimientos recientes</h2><table><tr><th>Fecha</th><th>Hora</th><th>Tipo</th><th>Concepto</th><th>Monto</th><th>Notas</th></tr>{% for x in rows %}<tr><td>{{ x.fecha }}</td><td>{{ x.hora }}</td><td>{{ x.tipo }}</td><td>{{ x.concepto }}</td><td>{{ x.monto }}</td><td>{{ x.usuario_notas }}</td></tr>{% endfor %}</table></div>"""
    return page("Caja", body, rows=rows, entradas=money(totals["entradas"]), salidas=money(totals["salidas"]))

@app.route("/consumo", methods=["GET", "POST"])
@login_required
def consumo():
    if request.method == "POST":
        try:
            concepto = request.form["concepto"].strip()
            cantidad = as_decimal(request.form["cantidad"])
            if not concepto or cantidad <= 0: raise ValueError("Concepto y cantidad deben ser válidos.")
            ident = datetime.now().strftime("I%Y%m%d%H%M%S%f")
            cur = db_cursor()
            cur.execute("SELECT unidad FROM inventario WHERE concepto=%s", (concepto,))
            item = cur.fetchone()
            if not item: raise ValueError("Ese concepto no existe en inventario.")
            inventory_change(cur, concepto, -cantidad, item["unidad"])
            cur.execute("INSERT INTO consumo_interno(id,fecha,hora,concepto,cantidad) VALUES(%s,CURDATE(),CURTIME(),%s,%s)",(ident,concepto,str(cantidad)))
            mysql.connection.commit(); cur.close()
            flash("Consumo interno registrado y descontado del inventario.")
            return redirect(url_for("consumo"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur=db_cursor(); cur.execute("SELECT concepto,cantidad,unidad FROM inventario ORDER BY concepto"); items=cur.fetchall()
    cur.execute("SELECT * FROM consumo_interno ORDER BY fecha DESC,hora DESC LIMIT 30"); rows=cur.fetchall(); cur.close()
    body = """
    <div class="card"><h2>Registrar consumo interno</h2><form method="post"><div class="grid"><div><label>Artículo</label><select name="concepto" required>{% for x in items %}<option value="{{ x.concepto }}">{{ x.concepto }} ({{ x.cantidad }} {{ x.unidad }})</option>{% endfor %}</select></div><div><label>Cantidad utilizada</label><input name="cantidad" type="number" min="0.001" step="0.001" required></div></div><p><button class="btn">Registrar consumo</button></p></form></div>
    <div class="card"><h2>Historial</h2><table><tr><th>Fecha</th><th>Hora</th><th>Concepto</th><th>Cantidad</th></tr>{% for x in rows %}<tr><td>{{ x.fecha }}</td><td>{{ x.hora }}</td><td>{{ x.concepto }}</td><td>{{ x.cantidad }}</td></tr>{% endfor %}</table></div>"""
    return page("Consumo interno", body, items=items, rows=rows)

@app.route("/cierres", methods=["GET", "POST"])
@login_required
def cierres():
    if request.method == "POST":
        try:
            fecha = request.form.get("fecha") or datetime.now().strftime("%Y-%m-%d")
            carne = as_decimal(request.form.get("carne_sobrante_kg","0"))
            tortillas = int(request.form.get("tortillas_sobrantes","0"))
            notas = request.form.get("notas","")
            if carne < 0 or tortillas < 0: raise ValueError("Los sobrantes no pueden ser negativos.")
            cur=db_cursor()
            cur.execute("""INSERT INTO cierres_dia(fecha,carne_sobrante_kg,tortillas_sobrantes,notas) VALUES(%s,%s,%s,%s)
            ON DUPLICATE KEY UPDATE carne_sobrante_kg=VALUES(carne_sobrante_kg),tortillas_sobrantes=VALUES(tortillas_sobrantes),notas=VALUES(notas)""",
            (fecha,str(carne),tortillas,notas))
            mysql.connection.commit(); cur.close(); flash("Cierre del día guardado.")
            return redirect(url_for("cierres"))
        except Exception as e:
            try: mysql.connection.rollback()
            except Exception: pass
            flash(str(e))
    cur=db_cursor(); cur.execute("SELECT * FROM cierres_dia ORDER BY fecha DESC LIMIT 30"); rows=cur.fetchall(); cur.close()
    body = """
    <div class="card"><h2>Cierre del día</h2><form method="post"><div class="grid"><div><label>Fecha</label><input name="fecha" type="date" value="{{ hoy }}" required></div><div><label>Carne sobrante (Kg)</label><input name="carne_sobrante_kg" type="number" min="0" step="0.001" value="0" required></div><div><label>Tortillas sobrantes</label><input name="tortillas_sobrantes" type="number" min="0" step="1" value="0" required></div><div><label>Notas</label><input name="notas"></div></div><p><button class="btn">Guardar cierre</button></p></form></div>
    <div class="card"><h2>Cierres recientes</h2><table><tr><th>Fecha</th><th>Carne sobrante (Kg)</th><th>Tortillas sobrantes</th><th>Notas</th></tr>{% for x in rows %}<tr><td>{{ x.fecha }}</td><td>{{ x.carne_sobrante_kg }}</td><td>{{ x.tortillas_sobrantes }}</td><td>{{ x.notas }}</td></tr>{% endfor %}</table></div>"""
    return page("Cierre del día", body, rows=rows, hoy=datetime.now().strftime("%Y-%m-%d"))

@app.route("/reportes")
@login_required
def reportes():
    desde = request.args.get("desde") or datetime.now().strftime("%Y-%m-01")
    hasta = request.args.get("hasta") or datetime.now().strftime("%Y-%m-%d")
    cur=db_cursor()
    cur.execute("SELECT COUNT(*) operaciones, COALESCE(SUM(total),0) vendido, COALESCE(SUM(monto_pagado),0) cobrado, COALESCE(SUM(saldo_pendiente),0) pendiente FROM ventas WHERE fecha BETWEEN %s AND %s",(desde,hasta))
    v=cur.fetchone()
    cur.execute("SELECT COALESCE(SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE 0 END),0) entradas,COALESCE(SUM(CASE WHEN tipo='SALIDA' THEN monto ELSE 0 END),0) salidas FROM movimientos_caja WHERE fecha BETWEEN %s AND %s",(desde,hasta))
    c=cur.fetchone()
    cur.execute("SELECT fecha,concepto,cantidad,p_unitario,total,metodo_pago,cliente,monto_pagado,saldo_pendiente FROM ventas WHERE fecha BETWEEN %s AND %s ORDER BY fecha DESC,hora DESC LIMIT 300",(desde,hasta))
    rows=cur.fetchall(); cur.close()
    body = """
    <div class="card"><h2>Reportes de ventas y caja</h2><form method="get"><div class="grid"><div><label>Desde</label><input type="date" name="desde" value="{{ desde }}"></div><div><label>Hasta</label><input type="date" name="hasta" value="{{ hasta }}"></div></div><p><button class="btn">Consultar</button></p></form>
    <div class="grid"><div>Operaciones: <div class="stats">{{ v.operaciones }}</div></div><div>Vendido: <div class="stats">{{ vendido }}</div></div><div>Cobrado en ventas: <div class="stats">{{ cobrado }}</div></div><div>Por cobrar: <div class="stats">{{ pendiente }}</div></div><div>Entradas caja: <div class="stats">{{ entradas }}</div></div><div>Salidas caja: <div class="stats">{{ salidas }}</div></div></div></div>
    <div class="card"><h2>Detalle de ventas</h2><table><tr><th>Fecha</th><th>Concepto</th><th>Cant.</th><th>Precio</th><th>Total</th><th>Pago</th><th>Cliente</th><th>Pagado</th><th>Pendiente</th></tr>{% for x in rows %}<tr><td>{{ x.fecha }}</td><td>{{ x.concepto }}</td><td>{{ x.cantidad }}</td><td>{{ x.p_unitario }}</td><td>{{ x.total }}</td><td>{{ x.metodo_pago }}</td><td>{{ x.cliente }}</td><td>{{ x.monto_pagado }}</td><td>{{ x.saldo_pendiente }}</td></tr>{% endfor %}</table></div>"""
    return page("Reportes", body, desde=desde, hasta=hasta, v=v, vendido=money(v["vendido"]), cobrado=money(v["cobrado"]), pendiente=money(v["pendiente"]), entradas=money(c["entradas"]), salidas=money(c["salidas"]), rows=rows)

@app.route("/exportar")
@login_required
def exportar():
    cur=db_cursor()
    cur.execute("SELECT transaccion_id,fecha,hora,concepto,cantidad,p_unitario,total,estado,metodo_pago,cliente,monto_pagado,saldo_pendiente FROM ventas ORDER BY fecha,hora")
    rows=cur.fetchall(); cur.close()
    output=io.StringIO()
    writer=csv.writer(output)
    writer.writerow(["transaccion_id","fecha","hora","concepto","cantidad","precio_unitario","total","estado","metodo_pago","cliente","monto_pagado","saldo_pendiente"])
    for r in rows:
        writer.writerow([r[k] for k in ["transaccion_id","fecha","hora","concepto","cantidad","p_unitario","total","estado","metodo_pago","cliente","monto_pagado","saldo_pendiente"]])
    return Response("\\ufeff"+output.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition":"attachment; filename=ventas_zuscarnitas.csv"})

@app.route("/health")
def health():
    return {"status":"ok", "app":"ZUSCARNITAS EL PICA"}

if __name__ == "__main__":
    try:
        setup_database()
        print("Tablas verificadas/creadas.")
    except Exception as e:
        print("No se pudo inicializar MySQL:", e)
        print("Verifica que MySQL esté encendido y que la base de datos exista.")
    app.run(host="127.0.0.1", port=5000, debug=True)
