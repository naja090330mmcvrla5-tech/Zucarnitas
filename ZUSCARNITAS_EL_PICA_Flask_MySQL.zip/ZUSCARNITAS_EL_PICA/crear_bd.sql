-- Ejecuta este archivo en MySQL Workbench o phpMyAdmin.
CREATE DATABASE IF NOT EXISTS zus_carnitas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- Luego selecciona la base de datos zus_carnitas.
-- app.py crea las tablas automáticamente al iniciar.
USE zus_carnitas;
